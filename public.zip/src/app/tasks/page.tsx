import React from 'react';
import Tasks from "@/components/pages/tasks/tasks";

const Page = () => {
    return (
        <Tasks/>
    );
};

export default Page;
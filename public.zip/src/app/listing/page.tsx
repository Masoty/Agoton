import React from 'react';
import Listing from "@/components/pages/listing/Listing";

const Page = () => {
    return (
        <Listing/>
    );
};

export default Page;
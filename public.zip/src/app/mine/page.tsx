import React from 'react';
import Mine from "@/components/pages/mine/Mine";

const Page = () => {
    return (
        <Mine/>
    );
};

export default Page;
import React from 'react';
import Friends from "@/components/pages/friends/Friends";

const Page = () => {
    return (
        <Friends/>
    );
};

export default Page;
import Home from "@/components/pages/home/home";


export default function Page() {

    return (
        <Home/>
    );

}

